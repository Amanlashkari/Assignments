/*Ask end user to enter following details 

 Roll no
 Student name
 Semester1 marks
 Semester 2 marks
 Semester 3 Marks
.....

Ask for four entries.
Calculate percentage of marks and store into file student.dat
*/

package com.yash.iofiles;
import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class userinput {
	
	public static void main(String[] args) {
		
		
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		for(int i=0;i<4;i++) {
		System.out.println("Enter Rollno: ");
		int rollno=scan.nextInt();
		System.out.println("Enter Name of Student: ");
		String name=scan.next();
		System.out.println("Enter semester1marks: ");
		int Semester1marks=scan.nextInt();
		System.out.println("Enter semester2marks: ");
		int Semester2marks=scan.nextInt();
		System.out.println("Enter semester3marks: ");
		int Semester3marks=scan.nextInt();
		System.out.println("Enter semester4marks: ");
		int Semester4marks=scan.nextInt();
		int total=Semester1marks+Semester2marks+Semester3marks+Semester4marks;
		int per=total/4;
			
		try {
			BufferedWriter writer=new BufferedWriter(new FileWriter("StudentData.dat"));
			writer.write("rollno: "+rollno);
			writer.write("\nName: "+name);
			writer.write("\nSemster1marks: "+Semester1marks);
			writer.write("\nSemster2marks: "+Semester2marks);
			writer.write("\nSemster3marks: "+Semester3marks);
			writer.write("\nSemster4marks: "+Semester4marks);
			writer.write("\npercentage: "+per);
			writer.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		try{
			BufferedReader reader=new BufferedReader(new FileReader("StudentData.dat"));
			String line;
			while((line=reader.readLine())!=null) {
				System.out.println(line);
		}	
			reader.close();
		}catch (IOException e) {
			System.err.println(e);
		}

		}
	}
}

	
	


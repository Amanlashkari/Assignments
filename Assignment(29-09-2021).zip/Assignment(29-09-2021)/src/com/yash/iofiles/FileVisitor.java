package com.yash.iofiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Scanner;


public class FileVisitor
{
	
	static long count = 1;
	public static void main(String[] args) {
	
		
		try (Scanner sc = new Scanner(System.in)) 
		{
			System.out.print("Enter the file Extension : ");
			String ext = sc.nextLine();
			System.out.print("Enter the path :");
			String path = sc.nextLine();
			File file = new File(path);
			Visitor visitor = new Visitor(ext,1);
			
			if (file.isDirectory()) {
				try {
					Path path2 = Paths.get(path);
					Files.walkFileTree(path2, visitor);
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("Invalid Path");
			}
			System.out.println("Total files Available in the folder:"+(visitor.getCount()-1));
		}
	}
}
class Visitor extends SimpleFileVisitor<Path>{
	
	private String extension;
	private int count1;
	
	public Visitor(String extension, int count1) {
		super();
		this.extension = extension;
		this.count1 = count1;
	}
	
	public String getExtension() {
		return extension;
	}

	public int getCount() {
		return count1;
	}

	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
		String matched = getExtension();
		if(file.getFileName().toString().endsWith(matched)) {
			System.out.println(this.count1+"_"+file.toFile().getPath());
			this.count1+=1;
		}
		return FileVisitResult.CONTINUE;
	}
}
package com.yash.repository;

import java.util.Arrays;

import java.util.List;
import com.yash.entity.Item;
import com.yash.entity.Product;
import com.yash.entity.SubCategory;
import com.yash.entity.category;

public class Repository {
		
		public static List<category> getCategory(){
			
			Item item1=new Item();
			item1.setItemId("ITEM01");
			item1.setItemDescription("ITEM 1 description");
			item1.setItemUnitPrice(5000);
			
			Item item2=new Item();
			item2.setItemId("ITEM02");
			item2.setItemDescription("ITEM 2 description");
			item2.setItemUnitPrice(4000);
			
			Item item3=new Item();
			item3.setItemId("ITEM03");
			item3.setItemDescription("ITEM 3 description");
			item3.setItemUnitPrice(6000);
			
			Product product1=new Product();
			product1.setProductId("PROD01");
			product1.setProductDescription("PROD 01 description");
			product1.setItems(Arrays.asList(new Item[] {item1,item2}));
			
			Product product2=new Product();
			product2.setProductId("PROD02");
			product2.setProductDescription("PROD 02 description");
			product2.setItems(Arrays.asList(new Item[] {item3}));
			
			
			SubCategory subCategory1=new SubCategory();
			subCategory1.setSubCategoryId("SubCategory01");
			subCategory1.setSubCategoryDescription("SubCategory 1 description");
			subCategory1.setProducts(Arrays.asList(new Product[] {product1}));
			
			SubCategory subCategory2=new SubCategory();
			subCategory2.setSubCategoryId("SubCategory02");
			subCategory2.setSubCategoryDescription("SubCategory 2 description");
			subCategory2.setProducts(Arrays.asList(new Product[] {product2}));
			
			category category1=new category();
			category1.setCategoryId("Category01");
			category1.setCategoryDescription("Category 1 description");
			category1.setCategories(Arrays.asList(new SubCategory[] {subCategory1}));
			
			category category2=new category();
			category2.setCategoryId("Category02");
			category2.setCategoryDescription("Category 2 description");
			category2.setCategories(Arrays.asList(new SubCategory[] {subCategory2}));
			
			return Arrays.asList(new category[] {category1,category2});
			
		}

	}


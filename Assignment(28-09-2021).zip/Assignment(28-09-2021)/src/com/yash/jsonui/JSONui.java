package com.yash.jsonui;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.yash.entity.category;
import com.yash.repository.Repository;
import com.yash.services.DeSerialized;
import com.yash.services.Serialized;

public class JSONui{
	public static void main(String[] args) throws FileNotFoundException, IOException 
	{
		List<category> categories = Repository.getCategory();
		Serialized ser = new Serialized();
		DeSerialized dser = new DeSerialized();
	
		File file = new File("C:\\Users\\aman.lashkari\\Documents\\workspace-spring-tool-suite-4-4.7.1.RELEASE\\Assignment(28-09-2021)\\categories.json");
		@SuppressWarnings("resource")
		PrintWriter pw = new PrintWriter(file);
		pw.write("");
		
		categories.forEach(x->{
			try {
				ser.Serializedtojson(x);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		category category = dser.deserilizedtojson();
		System.out.println(category);
	}
}

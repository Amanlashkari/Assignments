package com.yash.io;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.yash.entity.employee;

public class employeedeserialize {
	public static void main(String[] args){
	try(
		InputStream os=new FileInputStream("C:\\Users\\aman.lashkari\\Documents\\files\\employee.ser");	
		ObjectInputStream ois= new ObjectInputStream(os);
			){
			employee e=(employee)ois.readObject();
			System.out.println(e);
	}catch(IOException i) {
		i.printStackTrace();
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
}
}


//1. put student data into a file student.dat

 //101 sabbir 45 54 67 81 71 66
 //102 amit 95 66 62 88 79 63

//Read data from student.dat and compute percentage of each student and sort student data based on percentage.

package com.yash.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class files {
	public static void main(String[] args) {
	
	int rollno1=101;
	String name1="Aman";
	int sem1marks=55;
	int sem2marks=60;
	int sem3marks=73;
	int sem4marks=65;
	int sem5marks=56;
	int sem6marks=74;
	int total = sem1marks+sem2marks+sem3marks+sem4marks+sem5marks+sem6marks;
	int per=total/6;
	int rollno2=102;
	String name2="Ankit";
	int marks1=56;
	int marks2=83;
	int marks3=67;
	int marks4=50;
	int marks5=81;
	int marks6=65;
	int total1 = marks1+marks2+marks3+marks4+marks5+marks6;
	int per2=total1/6;
	try {
		BufferedWriter writer=new BufferedWriter(new FileWriter("StudentData.dat"));
		writer.write(""+rollno1);
		writer.write(" "+name1);
		writer.write(" "+sem1marks);
		writer.write(" "+sem2marks);
		writer.write(" "+sem3marks);
		writer.write(" "+sem4marks);
		writer.write(" "+sem5marks);
		writer.write(""+sem6marks);
		writer.write("\nThe percentage Of rollno1: " +per);
		writer.write("\n\n"+rollno2);
		writer.write(" "+name2);
		writer.write(" "+marks1);
		writer.write(" "+marks2);
		writer.write(" "+marks3);
		writer.write(" "+marks4);
		writer.write(" "+marks5);
		writer.write(" "+marks6);
		writer.write("\nThe percentage Of rollno2: " +per2);
		writer.close();
	}catch(IOException e) {
		System.err.println(e);
	}
	try{
		BufferedReader reader=new BufferedReader(new FileReader("StudentData.dat"));
		String line;
		while((line=reader.readLine())!=null) {
			System.out.println(line);
	}	
		reader.close();
	}catch (IOException e) {
		System.err.println(e);
	}
	}
}
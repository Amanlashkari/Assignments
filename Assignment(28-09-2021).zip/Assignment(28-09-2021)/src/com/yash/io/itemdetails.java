package com.yash.io;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.yash.entity.Item;

public class itemdetails {
	public static void main(String[] args){
		
		Item i=new Item();
		//i.setItemId(1001);
		i.setItemDescription("Samsung A51");
		i.setItemQuantityAvailable(10);
		i.setItemUnitPrice(10000);
		i.setItemDiscountPercentage(5);
		
		try(
			OutputStream os=new FileOutputStream("C:\\Users\\aman.lashkari\\Documents\\files\\Items.ser");	
			ObjectOutputStream oos=new ObjectOutputStream(os);	
				){
				oos.writeObject(i);
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}

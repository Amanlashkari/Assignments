package com.yash.io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.employee;
import com.yash.entity.manager;

public class employeeserialize {
	public static void main(String[] args) {
		
		employee e=new employee();
		e.setEmpId(1012747);
		e.setEmpFirstName("Aman");
		e.setLastName("Lashkari");
		e.setEmpDOB(14/10/1997);
		e.setEmpGender("male");

		manager manager = new manager();
		manager.setManagerId(1);
		List<manager> managerList = new ArrayList<>();
		managerList.add(manager);
		
		e.setmanager(managerList);
	
		try(
			OutputStream os=new FileOutputStream("C:\\Users\\aman.lashkari\\Documents\\files\\employee.ser");
				ObjectOutputStream oos=new ObjectOutputStream(os);
				){
			oos.writeObject(e);
		} catch (IOException e1) {
		
			e1.printStackTrace();
		}
		System.out.println();
		System.out.println(e);
		
	}
}

package com.yash.io;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

import com.yash.entity.Item;

public class inputserializableitems {
	
	public static void main(String[] args){
		
		try(
			InputStream is=new FileInputStream("C:\\Users\\aman.lashkari\\Documents\\files\\Items.ser");	
			ObjectInputStream ois=new ObjectInputStream(is);	
				){
			Item i= (Item)ois.readObject();
			System.out.println(i);
		}catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	

}

/*Create a class Employee with following attributes

    empId
    empFirstName
    empLastName
    empDOB
    empGender

  create subclass Manager of Employee with following attributes
	managerId
  Serialize object of manager except empDOB and deserialize and print details on console.
*/

package com.yash.entity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class employee implements Serializable{
	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		int empId;
		String empFirstName;
		String LastName;
		transient int empDOB;
		String empGender;
		List<manager> manageList=new ArrayList<>();
		private List<manager> managerList;
		
		
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpFirstName() {
			return empFirstName;
		}
		public void setEmpFirstName(String empFirstName) {
			this.empFirstName = empFirstName;
		}
		public String getLastName() {
			return LastName;
		}
		public void setLastName(String lastName) {
			LastName = lastName;
		}
		public int getEmpDOB() {
			return empDOB;
		}
		public void setEmpDOB(int empDOB) {
			this.empDOB = empDOB;
		}
		public String getEmpGender() {
			return empGender;
		}
		public void setEmpGender(String empGender) {
			this.empGender = empGender;
		}
		public List<manager> getmanager() {
			return manageList;		
			
		}
		public void setmanager(List<manager> managerList) {
			this.managerList = managerList;
			
		}
		@Override
		public String toString() {
			return "employee [empId=" + empId + ", empFirstName=" + empFirstName + ", LastName=" + LastName
					+ ", empDOB=" + empDOB + ", empGender=" + empGender +", manager=" + managerList + "]";
		}
		
		
}


//Create a class Item with following attributes

  // itemId int
   //itemDescription String
   //itemQuantityAvailable int
   //itemUnitPrice double
   //itemDiscountPercentage int

 //Serialize List of Items(at least 4 items) and deserialize those items and print on console.

package com.yash.entity;
import java.io.Serializable;

public class Item implements Serializable{
		
	private static final long serialVersionUID = 2L;
	   String itemId;
	   String itemDescription;
	   int itemQuantityAvailable;
	   int itemUnitPrice;
	   int itemDiscountPercentage;
	   
	   public Item() {}
	   
	   
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public int getItemQuantityAvailable() {
		return itemQuantityAvailable;
	}
	public void setItemQuantityAvailable(int itemQuantityAvailable) {
		this.itemQuantityAvailable = itemQuantityAvailable;
	}
	public int getItemUnitPrice() {
		return itemUnitPrice;
	}
	public void setItemUnitPrice(int itemUnitPrice) {
		this.itemUnitPrice = itemUnitPrice;
	}
	public int getItemDiscountPercentage() {
		return itemDiscountPercentage;
	}
	public void setItemDiscountPercentage(int itemDiscountPercentage) {
		this.itemDiscountPercentage = itemDiscountPercentage;
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemDescription=" + itemDescription + ", itemQuantityAvailable="
				+ itemQuantityAvailable + ", itemUnitPrice=" + itemUnitPrice + ", itemDiscountPercentage="
				+ itemDiscountPercentage + "]";
	} 
}
	
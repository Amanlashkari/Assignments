package com.yash.entity;

import java.io.Serializable;

public class manager implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int managerId;
	
	public manager() {}
	
	public manager(int managerId) {
		super();
		this.managerId = managerId;
	}



	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + "]";
	}
		
}
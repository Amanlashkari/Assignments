package com.yash.services;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import org.codehaus.jackson.map.ObjectMapper;
import com.yash.entity.category;

public class DeSerialized {
	

		public category deserilizedtojson() throws FileNotFoundException, IOException {
			ObjectMapper mapper = new ObjectMapper();
			try(InputStream is = new FileInputStream("C:\\Users\\aman.lashkari\\Documents\\workspace-spring-tool-suite-4-4.7.1.RELEASE\\Assignment(28-09-2021)\\categories.json"))
			{
				category readValue = mapper.readValue(is,category.class);
				return readValue;
			}
		}
	}
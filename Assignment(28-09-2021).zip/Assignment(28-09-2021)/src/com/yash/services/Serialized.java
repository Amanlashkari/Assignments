package com.yash.services;

import java.io.File;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.yash.entity.category;
public class Serialized {

		public void Serializedtojson(category category) throws JsonGenerationException, JsonMappingException, IOException {
			ObjectMapper mapper=new ObjectMapper();
			
			File file=new File("C:\\Users\\aman.lashkari\\Documents\\workspace-spring-tool-suite-4-4.7.1.RELEASE\\Assignment(28-09-2021)\\categories.json");
			try(OutputStream os=new FileOutputStream(file,true))
			{
				mapper.writeValue(os, category);
			}
		}
}

package com.yash.test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class Parameterizedtest {

	@ParameterizedTest
	@ValueSource(ints ={15,20,21,12,25})
	void testArrayEvenElements(int element) 
	{
		assertTrue(element%2==0);
	}

}
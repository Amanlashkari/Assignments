package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import com.yash.meta.Feature1;
import com.yash.meta.Feature2;
import com.yash.service.ArrayOperation;
import com.yash.service.Calculator;

class MetaAnnotationsTest {

	@Feature1
	void testArraysorting() 
	{
		ArrayOperation o = new ArrayOperation();
		int []arrayInput = {20,43,5,66,78,13,23};
		int []expected = {5,13,20,23,43,66,78};
		int []actual = o.sortArray(arrayInput);
		assertArrayEquals(expected, actual);
	}
	
	@Feature2
	void testCalculatorOperation() 
	{
		Calculator calc = new Calculator();
		int expected = 120;
		int no1=1200;
		int no2=10;
		int actual = calc.computeDivision(no1,no2);
		assertEquals(expected, actual);
	}

}
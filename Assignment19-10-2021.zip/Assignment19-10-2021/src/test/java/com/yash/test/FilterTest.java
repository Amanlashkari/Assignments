package com.yash.test;

import java.util.List;
import org.hamcrest.Matcher;
import org.hamcrest.core.IsCollectionContaining;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;


import com.yash.service.GetList;

@SuppressWarnings("deprecation")
class FilterTest {

	private List<Integer> list;

	@BeforeEach
	void setUp() throws Exception {
		list = new GetList().getIntegerList();
	}

	@AfterEach
	void tearDown() throws Exception {
		list=null;
	}

	@DisplayName("Test 1 : To check elements are available in list or not")
	@Test
	void test() {
		assertThat(list,IsCollectionContaining.hasItems(9,10,2));
	}
	
	private void assertThat(List<Integer> list2, Matcher<Iterable<Integer>> hasItems) {
		// TODO Auto-generated method stub
		
	}
}


package com.yash.junit5;

import java.util.ArrayList;
import java.util.List;

public class Lists {
	public List<Integer> getIntegerList(){
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(9);
		list.add(34);
		list.add(9);
		list.add(54);
		list.add(10);
		
		return list;
	}
}
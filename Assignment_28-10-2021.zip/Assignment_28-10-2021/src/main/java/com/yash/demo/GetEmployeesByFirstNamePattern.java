package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

import com.yash.entity.Employees;

public class GetEmployeesByFirstNamePattern {

	public static void main(String[] args) {
		
		ResourceBundle resourceBundle=ResourceBundle.getBundle("db");
		String driver=resourceBundle.getString("driver");
		String url=resourceBundle.getString("url");
		String username=resourceBundle.getString("username");
		String password=resourceBundle.getString("password");
		String patternToMatch=null;
		
		List<Employees> employeeList= new ArrayList<>();
		Employees employee=new Employees();
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try(
				  Scanner scanner=new Scanner(System.in);
				  Connection con=DriverManager.getConnection(url,username,password);
				  ){
					
					System.out.print("Enter pattern to match first name:");
			
					if(scanner.hasNext()) {
						patternToMatch=scanner.next();
					}
					PreparedStatement getEmployeeFirstNameLike=con.prepareStatement("select * from employees where first_name like ?");
					getEmployeeFirstNameLike.setString(1, patternToMatch);
					ResultSet resultSetEmployeeDetails=getEmployeeFirstNameLike.executeQuery();
					
					while(resultSetEmployeeDetails.next()) {
						
						
						//Setting data in Employee entitiy class
						employee.setEmployeeId(resultSetEmployeeDetails.getInt("employee_id"));
						employee.setFirstName(resultSetEmployeeDetails.getString("first_name"));
						employee.setLastName(resultSetEmployeeDetails.getString("last_name"));
						employee.setEmail(resultSetEmployeeDetails.getString("email"));
						employee.setPhoneNumber(resultSetEmployeeDetails.getString("phone_number"));
						employee.setHireDate(resultSetEmployeeDetails.getDate("hire_date").toLocalDate());
						employee.setJobId(resultSetEmployeeDetails.getString("job_id"));
						employee.setSalary(resultSetEmployeeDetails.getDouble("salary"));
						employee.setCommissionPCT(resultSetEmployeeDetails.getDouble("commission_pct"));
						employee.setManagerId(resultSetEmployeeDetails.getInt("manager_id"));
						employee.setDepartmentId(resultSetEmployeeDetails.getInt("department_id"));
						employeeList.add(employee);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
		System.out.println(employee);
	}

}

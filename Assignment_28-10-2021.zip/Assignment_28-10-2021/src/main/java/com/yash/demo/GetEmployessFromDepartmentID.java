package com.yash.demo;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Employees;

public class GetEmployessFromDepartmentID {

	public static void main(String[] args) {
		
		try {
			//Loading Driver Class
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		List<Employees> employeesList=new ArrayList<>();
		Employees employee=new Employees();

	//Creating Connection to database
			try (Scanner scanner = new Scanner(System.in);
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hr","root","root");){
				
				System.out.print("Enter Department ID:");
				int department_id=0;
				department_id=scanner.nextInt();
				
				//Creating SQL Statement
				PreparedStatement Statement=connection.prepareStatement("select * from employees where department_id=?");
				
				
				Statement.setInt(1, department_id);
				
				//Executing Query
				ResultSet resultSet=Statement.executeQuery();
				
				//Fetching rows from database table
				while(resultSet.next()) {
				
					//Setting data in Employee entitiy class
					employee.setEmployeeId(resultSet.getInt("employee_id"));
					employee.setFirstName(resultSet.getString("first_name"));
					employee.setLastName(resultSet.getString("last_name"));
					employee.setEmail(resultSet.getString("email"));
					employee.setPhoneNumber(resultSet.getString("phone_number"));
					employee.setHireDate(resultSet.getDate("hire_date").toLocalDate());
					employee.setJobId(resultSet.getString("job_id"));
					employee.setSalary(resultSet.getDouble("salary"));
					employee.setCommissionPCT(resultSet.getDouble("commission_pct"));
					employee.setManagerId(resultSet.getInt("manager_id"));
					employee.setDepartmentId(resultSet.getInt("department_id"));
					employeesList.add(employee);
			
				}
				
			}  catch (SQLException e) {
				e.printStackTrace();
			}	
			for(Employees employees:employeesList) {
				System.out.println(employees);
			}
			
		}

	}


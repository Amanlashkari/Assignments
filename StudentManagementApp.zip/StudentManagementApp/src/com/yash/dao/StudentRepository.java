package com.yash.dao;

import java.util.ArrayList;
import com.yash.entity.Student;
import java.util.List;
import java.util.Scanner;

import com.yash.view.MainView;

public class StudentRepository {
	
	
	static List<Student> studentRecord= new ArrayList<>();
	static List<Student> updateRecord= new ArrayList<>();
	static Scanner input = new Scanner(System.in);
	
	public void registerStudent()
	{
		System.out.println("Student Registration");
		
		System.out.println("1. Enter Student ID: ");
        int ID = input.nextInt();
        input.nextLine();
        
		System.out.print("Enter First Name :");
		String fname= input.next();
		
		System.out.print("Enter Last Name :");
		String lname= input.next();
		
		System.out.print("Enter Date of birth :");
		String dob= input.next();
		
		System.out.print("Enter gender :");
		String gender= input.next();
		
		System.out.print("Enter Course :");
		String course= input.next();
		
		Student student =new Student();
		
		student.setID(ID);
		student.setStudentFirstName(fname);
		student.setStudentLastName(lname);
		student.setStudentDob(dob);
		student.setStudentGender(gender);
		student.setStudentCourse(course);
		
		studentRecord.add(student);
		System.out.println("Student Registered");
		System.out.println("\n");
		
		MainView mvObj =new MainView();
		mvObj.mainMenu();
	}
	
	public void viewStudent()
	{
		int count=1;
		for(Student obj: studentRecord)
		System.out.println("1000" + count + obj);
		count++;
	}
	public void updateStudent() {
	
		System.out.println("Enter student ID to be update");
		int ID=input.nextInt();
		
	}

	public void removeStudent()
	{
		System.out.println("Enter student ID to be removed");
		int id=input.nextInt();
		studentRecord.remove(id);
	}
	
	public void exitMainMenu()
	{
		System.exit(0);
	}
}

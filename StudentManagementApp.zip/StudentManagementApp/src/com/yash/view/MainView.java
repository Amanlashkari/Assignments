package com.yash.view;
import java.util.Scanner;
import com.yash.dao.StudentRepository;

public class MainView {
	
	public void mainMenu()
	{
		System.out.println("<-----Student Management Application----->");
		System.out.println("1. Register Student");
		System.out.println("2. View Student Details");
		System.out.println("3. Update Student Details");
		System.out.println("4. Delete Student Record");
		System.out.println("5. Exit");
		System.out.println("<---------------------------------------->");
		
		Scanner input=new Scanner(System.in);
		int inputOption = input.nextInt();
		
		StudentRepository obj = new StudentRepository();
		
		switch(inputOption)
		{
		case 1: obj.registerStudent();
				break;
				
		case 2: obj.viewStudent();
				break;
				
		case 3: obj.updateStudent();
				break;
		
		case 4: obj.removeStudent();
				break;
		
		case 5: obj.exitMainMenu();
				break;

		default: System.out.println("Invalid Choice");
		}
	}
}
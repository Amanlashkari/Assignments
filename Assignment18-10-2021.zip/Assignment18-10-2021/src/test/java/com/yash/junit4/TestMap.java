/* For a given map it has a key -1001 and value- 10000
*/

package com.yash.junit4;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestMap {

	private Map<Integer,Integer> map;

	@Before
	public void setUp() throws Exception {
		map = new HashMap<Integer,Integer>();
		map.put(1001, 12029);
		map.put(1021, 233);
		map.put(1031, 33322);
		map.put(1201, 4353);
		map.put(1101, 23243);
		map.put(-1001, -10000);
		map.put(-10034, 432);	
	}

	@After
	public void tearDown() throws Exception {
		map=null;
	}

	@Test
	public void testMapContainsSpecificKeyAndValue() 
	{
		assertThat(map,hasEntry(-1001, -10000));
	}

}
/*For a given String it starts with "S" and endwith with "h"
*/

package com.yash.junit4;


import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class TestNullReference {

	@Test
	public void testObjectReferenceIsNull() {
		Object obj = null;
		assertThat(obj, nullValue());
	}
	
	@Test
	public void testObjectReferenceIsNotNull() {
		Object obj = new Object();
		assertThat(obj, notNullValue());
	}

}
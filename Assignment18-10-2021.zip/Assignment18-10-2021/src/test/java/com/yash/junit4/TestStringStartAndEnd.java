/*For a given reference variable it is not null
*/

package com.yash.junit4;


import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;
import org.junit.Test;

public class TestStringStartAndEnd {

	@Test
	public void testStringStartWith_S_And_EndsWith_H() {
		String str = "Some people are from HimachalPradesh";
		assertThat(str,startsWith("S"));
		assertThat(str, endsWith("h"));
	}

}

package com.yash.junit4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestList.class, TestMap.class, TestNullReference.class, TestStringStartAndEnd.class })
public class Test {
	
}
package com.yash.services;

import java.util.List;

import com.yash.entity.Student;

public class countFirstNameWithK {
	public static void main(String[] args) {
		List<Student> students = Student.getStudents();
		long count = students
		.stream()
		.filter(name->name.getFirstName().startsWith("K"))
		.count();
		
		System.out.println("Students count whose name starts with 'K' is: "+count);
	}
}
package com.yash.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import com.yash.entity.Student;

public class SemHighestAndLeastScore {
	public static void main(String[] args) 
	{
		List<Student> students = Student.getStudents();
		students.forEach(x->{
			Map<String,Integer> map = new HashMap<>();
			System.out.println("\nStudent");
			map.put("Semester 1",x.getSemester1Marks());
			map.put("Semester 2",x.getSemester2Marks());
			map.put("Semester 3",x.getSemester3Marks());
			map.put("Semester 4",x.getSemester4Marks());
			map.put("Semester 5",x.getSemester5Marks());
			map.put("Semester 6",x.getSemester6Marks());
			Optional<Entry<String,Integer>> min = map
					.entrySet()
					.stream()
					.min((o1,o2)->o1.getValue().compareTo(o2.getValue()));
			Optional<Entry<String,Integer>> max = map
					.entrySet()
					.stream()
					.max((o1,o2)->o1.getValue().compareTo(o2.getValue()));
			
			System.out.println("Name : "+x.getFirstName()+" "+x.getLastName());
			System.out.println("Roll No : "+x.getRollNo());
			if(max.isPresent()) {
				System.out.println("Highest Marks : "+max.get().getValue() + " in "+max.get().getKey());				
			}
			if(min.isPresent()) {
				System.out.println("Least Marks : "+min.get().getValue() + " in "+min.get().getKey());				
			}
			System.out.println("===============================================================================");
		});
	}
}
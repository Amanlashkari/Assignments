package com.yash.entity;

import java.util.Arrays;
import java.util.List;

public class Student {
	int rollNo;
    String firstName;
    String lastName;
    int semester1Marks;
    int semester2Marks;
    int semester3Marks;
    int semester4Marks;
    int semester5Marks;
    int semester6Marks;
    
    
private Student() {
		
	}
	
	
	private Student(Student.Builder builder) {
		this.rollNo=builder.rollNo;
		this.firstName=builder.firstName;
		this.lastName=builder.lastName;
		this.semester1Marks=builder.semester1Marks;
		this.semester2Marks=builder.semester2Marks;
		this.semester3Marks=builder.semester3Marks;
		this.semester4Marks=builder.semester4Marks;
		this.semester5Marks=builder.semester5Marks;
		this.semester6Marks=builder.semester6Marks;
	}
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSemester1Marks() {
		return semester1Marks;
	}
	public void setSemester1Marks(int semester1Marks) {
		this.semester1Marks = semester1Marks;
	}
	public int getSemester2Marks() {
		return semester2Marks;
	}
	public void setSemester2Marks(int semester2Marks) {
		this.semester2Marks = semester2Marks;
	}
	public int getSemester3Marks() {
		return semester3Marks;
	}
	public void setSemester3Marks(int semester3Marks) {
		this.semester3Marks = semester3Marks;
	}
	public int getSemester4Marks() {
		return semester4Marks;
	}
	public void setSemester4Marks(int semester4Marks) {
		this.semester4Marks = semester4Marks;
	}
	public int getSemester5Marks() {
		return semester5Marks;
	}
	public void setSemester5Marks(int semester5Marks) {
		this.semester5Marks = semester5Marks;
	}
	public int getSemester6Marks() {
		return semester6Marks;
	}
	public void setSemester6Marks(int semester6Marks) {
		this.semester6Marks = semester6Marks;
	}
	
	
	public static class Builder {
		int rollNo;
	    String firstName;
	    String lastName;
	    int semester1Marks;
	    int semester2Marks;
	    int semester3Marks;
	    int semester4Marks;
	    int semester5Marks;
	    int semester6Marks;
	    
	    public Builder setRollno(int rollNo) {
	    	this.rollNo=rollNo;
	    	return this;
	    }
	    public Builder setFirstName(String firstName) {
	    	this.firstName=firstName;
	    	return this;
	    }
	    public Builder setLastName(String lastName) {
			this.lastName = lastName;
			return this;
		}
		public Builder setSemester1Marks(int semester1Marks) {
			this.semester1Marks = semester1Marks;
			return this;
		}
		public Builder setSemester2Marks(int semester2Marks) {
			this.semester2Marks = semester2Marks;
			return this;
		}
		public Builder setSemester3Marks(int semester3Marks) {
			this.semester3Marks = semester3Marks;
			return this;
		}
		public Builder setSemester4Marks(int semester4Marks) {
			this.semester4Marks = semester4Marks;
			return this;
		}
		public Builder setSemester5Marks(int semester5Marks) {
			this.semester5Marks = semester5Marks;
			return this;
		}
		public Builder setSemester6Marks(int semester6Marks) {
			this.semester6Marks = semester6Marks;
			return this;
		}
		
		public Student build() {
			return new Student(this);
		}
	
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", firstName=" + firstName + ", lastName=" + lastName + ", semester1Marks="
				+ semester1Marks + ", semester2Marks=" + semester2Marks + ", semester3Marks=" + semester3Marks
				+ ", semester4Marks=" + semester4Marks + ", semester5Marks=" + semester5Marks + ", semester6Marks="
				+ semester6Marks + "]";
	}
	
	public static List<Student> getStudents(){
		return Arrays.asList(
				new Builder()
						.setRollno(101)
						.setFirstName("Aman")
						.setLastName("Lashkari")
						.setSemester1Marks(60)
						.setSemester2Marks(56)
						.setSemester3Marks(67)
						.setSemester4Marks(67)
						.setSemester5Marks(88)
						.setSemester6Marks(95)
						.build(),
				new Builder()
						.setRollno(102)
						.setFirstName("Amay")
						.setLastName("Mandloi")
						.setSemester1Marks(60)
						.setSemester2Marks(56)
						.setSemester3Marks(54)
						.setSemester4Marks(57)
						.setSemester5Marks(78)
						.setSemester6Marks(87)
						.build(),
				new Builder()
						.setRollno(103)
						.setFirstName("Avinash")
						.setLastName("Vishwakarma")
						.setSemester1Marks(79)
						.setSemester2Marks(66)
						.setSemester3Marks(56)
						.setSemester4Marks(87)
						.setSemester5Marks(69)
						.setSemester6Marks(91)
						.build(),
				new Builder()
						.setRollno(104)
						.setFirstName("Amit")
						.setLastName("Verma")
						.setSemester1Marks(84)
						.setSemester2Marks(55)
						.setSemester3Marks(65)
						.setSemester4Marks(67)
						.setSemester5Marks(86)
						.setSemester6Marks(56)
						.build(),
				new Builder()
						.setRollno(105)
						.setFirstName("Himanshu")
						.setLastName("Kulshreshta")
						.setSemester1Marks(76)
						.setSemester2Marks(97)
						.setSemester3Marks(56)
						.setSemester4Marks(76)
						.setSemester5Marks(56)
						.setSemester6Marks(76)
						.build()
				);
	}
}

	


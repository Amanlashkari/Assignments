package com.yash.services;

import java.util.List;

import com.yash.newpack.StudentSort;
import com.yash.model.StudentModel;

public interface StudentService {
	List<StudentModel> retrieveStudentService(StudentSort sortBy);
}

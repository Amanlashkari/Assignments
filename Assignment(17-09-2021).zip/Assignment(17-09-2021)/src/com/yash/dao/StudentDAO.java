package com.yash.dao;

import java.util.List;

import com.yash.model.StudentModel;

public interface StudentDAO {

	boolean storeStudentData(StudentModel student);

	List<StudentModel> retriveStudentData();

}

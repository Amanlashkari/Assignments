package com.yash.view;

import java.util.List;


import com.yash.newpack.StudentSort;
import com.yash.newpack.Student;
import com.yash.model.StudentModel;

public class StudentViews
{	
	private static Student controller = new Student();
	
	public static void displayAllStudentData(StudentSort sortType) 
	{
		System.out.println("\n=========================================== Required Data ===========================================\n");
		List<StudentModel> retrieveStudentService = controller.handleStudentDataRequest(sortType);
		for (StudentModel studentModel : retrieveStudentService) {
			System.out.println(studentModel);
		}
		System.out.println("\n============================= %%%%%%%%%%%%% ================================\n");
	}
	
}
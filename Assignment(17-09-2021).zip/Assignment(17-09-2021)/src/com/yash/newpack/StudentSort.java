package com.yash.newpack;


public enum StudentSort {
	ROLLNO("ROLLNO"),FIRSTNAME("FIRSTNAME"),LASTNAME("LASTNAME"),AGE("AGE"),PERCENTAGE("PERCENTAGE");
	private String val;
	private StudentSort(String val) {
		this.val=val;
	}
	public String getValue() {
		return val;
	}
}
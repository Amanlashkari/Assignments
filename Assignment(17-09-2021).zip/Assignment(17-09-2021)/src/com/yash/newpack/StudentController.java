package com.yash.newpack;

import java.util.List;

import com.yash.dao.StudentDAO;
import com.yash.factory.factory;
import com.yash.model.StudentModel;
import com.yash.services.StudentService;

public class StudentController {
	public boolean handleStudentRegister(StudentModel model) {
		StudentDAO studentDao = factory.getMemoryStudentDAO();
		return studentDao.storeStudentData(model);
	}
	
	public List<StudentModel> handleStudentDataRequest(StudentSort sortType) 
	{
		StudentService studentService= factory.getStudentFactory();
		return studentService.retrieveStudentService(sortType);
	}
}
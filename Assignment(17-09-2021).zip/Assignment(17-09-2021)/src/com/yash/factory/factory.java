package com.yash.factory;

import com.yash.dao.StudentDAO;
import com.yash.dao.StudentImpl;
import com.yash.services.StudentService;
import com.yash.services.StudentServiceImpl;

public class factory {
	public static StudentService getStudentFactory() {
		return new StudentServiceImpl();
	}
	
	public static StudentDAO getMemoryStudentDAO() {
		return new StudentImpl();
	}
}
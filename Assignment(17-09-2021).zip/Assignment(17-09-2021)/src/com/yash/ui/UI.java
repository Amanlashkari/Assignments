package com.yash.ui;
import com.yash.view.Mainclass;

public class UI {
	public static void main(String[] args) {
		Mainclass.mainView();
	}
}
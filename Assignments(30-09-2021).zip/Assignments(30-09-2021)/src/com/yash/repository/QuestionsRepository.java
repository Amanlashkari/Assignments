package com.yash.repository;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.yash.entity.Option;
import com.yash.entity.Questionss;
import com.yash.entity.Subject;

public class QuestionsRepository {

	private List<String> questionsList;
	private Option op;
	private List<Questionss> q;
	private static List<Subject> subjectsList = new LinkedList<Subject>();
	
	public List<Subject> getSubjectsList(){
		loadCollectionOfJava();

		return subjectsList;
	}
	
	public void setUp() {
		questionsList = new LinkedList<>();
		q=new ArrayList<Questionss>();
		op = new Option();
	}
	
	public void load() {
		Questionss ques = new Questionss();
		ques.setQuestions(questionsList);
		ques.setOption(op);		
		q.add(ques);
	}
	
	public void loadCollectionOfJava(){
		setUp();
		questionsList.add("WWhich of these standard collection classes implements a dynamic array?");
		op.setOptions("ArrayList", false);
		op.setOptions("LinkedList", true);
		op.setOptions("AbstractList", false);
		op.setOptions("AbstractSet", false);
		load();
		
		op=new Option();
		questionsList.add("Which of these class can generate an array which can increase and decrease in size automatically?");
		op.setOptions("DynamicList()", false);
		op.setOptions("LinkedList()", false);
		op.setOptions("ArrayList()", true);
		op.setOptions("ArraySet()", false);
		load();
		
		op = new Option();
		questionsList.add("Which of these method can be used to increase the capacity of ArrayList object manually?");
		op.setOptions("IncreaseCapacity", false);
		op.setOptions("DecreaseCapacity", false);
		op.setOptions("capacity", false);
		op.setOptions("ensureCapacity", true);
		load();

		op = new Option();
		questionsList.add("Which of these method of ArrayList class is used to obtain present size of an object?");
		op.setOptions("Index()", true);
		op.setOptions("Size()", false);
		op.setOptions("Capacity()", false);
		op.setOptions("Length()", false);
		load();

		op = new Option();
		questionsList.add("Which of these methods can be used to obtain a static array from an ArrayList object?");
		op.setOptions("Array()", false);
		op.setOptions("toArray()", false);
		op.setOptions("convertToArray()", false);
		op.setOptions("convertArray()", true);
		load();
	
		Subject s = new Subject(101, "collectionofJava", q);
		subjectsList.add(s);
	}
}



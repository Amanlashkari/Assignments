package com.yash.service;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberCheck {

	private MobileCheck mobileCheck;

	public NumberCheck(MobileCheck mobileCheck){
	this.mobileCheck=mobileCheck;
	}

	public boolean check(String number){
	  
	return mobileCheck.CheckMobileNumber(number);
	}

	}

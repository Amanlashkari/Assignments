package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.service.ArrayFourthLargestElement;

public class TestArrayFourthlargestelement {

	private ArrayFourthLargestElement element;

	@Before
	public void setUp() throws Exception {
		element = new ArrayFourthLargestElement();
	}

	@After
	public void tearDown() throws Exception {
		element=null;
	}

	@Test
	public void testArray_NthLargestElementPositive() {
		int inputArr[]= {10,20,32,12,15,17,43};
		int expected = 17;
		int index=4;
		int actual = element.getFourthLargest(inputArr,index);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testArray_NthLargestElementNegative() {
		int inputArr[]= {4,6,2};
		int index=4;
		try {
			element.getFourthLargest(inputArr, index);
			assertTrue(true);
		}
		catch(Exception e) {
			System.err.println(e);
			assertTrue(false);
		}
	}
	
	@Test
	public void testArray_ExceptionWhen_Nth_ValueIsGreaterThanSize() {
		int inputArr[]= {3,5,7,2,23,43,54,64,213,12};
		int index=inputArr.length+1;;
		element.getFourthLargest(inputArr, index);
		assertTrue(true);
	}

}
package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.service.CountDuplicateString;

public class CountDuplicateStrings {
	

	private CountDuplicateString  duplicateStringElements;

	@Before
	public void setUp() throws Exception {
		duplicateStringElements = new CountDuplicateString ();
	}

	@After
	public void tearDown() throws Exception {
		duplicateStringElements=null;
	}

	@Test
	public void testCountDuplicateStrings_positive() 
	{
		String[] inputArr= {"jim","Tom","Lio","Tokyo","jim","Tom","kim","kio","jim","kio"};
		int expected = 4;
		int actual = duplicateStringElements.getDuplicateCount(inputArr);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testCountDuplicateStrings_negative() 
	{
		String[] inputArr = {"jim"};
		int expected = 0;
		int actual = duplicateStringElements.getDuplicateCount(inputArr);
		assertEquals(expected, actual);
	}
	

}